#include <stdio.h>
#include <stdlib.h>

void atvalt_kiir(int x, int szr)
{
    if (x >= szr){
        atvalt_kiir(x / szr, szr);
    }
    printf("%d", x % szr);
}

int main()
{
    int szam, szamrendszer;

    printf("Szam: ");
    scanf("%d", &szam);
    printf("Szamrendszer: ");
    scanf("%d", &szamrendszer);

    atvalt_kiir(szam, szamrendszer);

    return 0;
}
