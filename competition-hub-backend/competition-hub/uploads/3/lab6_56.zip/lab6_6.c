#include <stdio.h>
#include <stdlib.h>

void felbontas(int x)
{
    if (x >= 1000){
        felbontas(x/1000);
    }
    printf("%03d ", x % 1000);
}

int main()
{
    int szam;
    printf("A szam: ");
    scanf("%d", &szam);
    felbontas(szam);

    return 0;
}
