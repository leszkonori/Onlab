package backend.competition_hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompetitionHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
