package backend.competition_hub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompetitionHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompetitionHubApplication.class, args);
	}

}
